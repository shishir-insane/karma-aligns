// Server component that renders the client landing page (form)
import AstroLanding from "@/components/landing/AstroLanding";

export default function Page() {
  return <AstroLanding />;
}
